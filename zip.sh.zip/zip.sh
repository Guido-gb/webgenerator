zip -r $1.zip $1
